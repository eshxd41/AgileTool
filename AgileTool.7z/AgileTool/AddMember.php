<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        
      $title = "Add Member";
      $content ='</>
<h1> AGILE TOOL <h1>
        <h2>Add Member for the project </h2>
        
        First Name: <input type="text" name="firstname" placeholder="first name">
        Last Name: <input type="text" name="lastname" placeholder="Last name">
        <p>

       Role: <select name="formGender">
                <option >coach</option>
                <option >Developer</option>
                <option >Tester</option>
                <option >Manager</option>
            </select>
        </p>
        <button type="submit">Add Member </button>
        
      <h7> </h7>';
        
      //$title ="Add Member";
     // $content ="This is where u add member";
      
              
 // put your code here
      
 include 'Template.php'; 
      
        // put your code here
        ?>
        
  
  
  
