 <?php
      $title = "Home";
      $content ='<img src="Images/EPITA.png" class="imgLeft"/>
<h1> AGILE TOOL <h1>
        <p>By Ganesh Suresh Viquar</p>
        <p> This is tool developed to be  used as to manage the projects and project members and the team</p>';
      //$title ="Add Member";
     // $content ="This is where u add member";
      
              
 // put your code here
      
 include 'Template.php'; 
      ?>
