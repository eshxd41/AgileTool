
        <?php
        $title ="All Projects";
        $content ='<h1> ALL Projects <h1>'
                .'<h3>all the projects are shown below </h3>'
                . '<h4> SELECT * FROM agile_tool.project;<h4>';
        
        include 'Template.php';
        ?>


