<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $title ="Registration Form";
        $content ='<h1> Register Form <h1>';
        include 'Template.php';
        ?>
    </body>
</html>
